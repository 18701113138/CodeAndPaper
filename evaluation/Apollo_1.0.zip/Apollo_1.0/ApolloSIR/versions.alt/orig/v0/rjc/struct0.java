package rjc;

public class struct0 {
  public double signal1 = 0;
  public double signal2 = 0;
}

